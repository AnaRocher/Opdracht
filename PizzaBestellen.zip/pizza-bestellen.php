<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza bestellen</title>
    <link rel="stylesheet" href="pizza-bestellen.css">
</head>
<body>

    <div class="container">
        <header>
            <h1>Stel je eigen pizza samen</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat cupiditate iure vero, soluta ipsum voluptate non aliquid dicta voluptatem eum?</p>
        </header>

        <form>
            <fieldset class="has_error">
                <legend>Basis</legend>
                <div class="has_error">
                    <label>
                        <span class="label">Grootte:</span> 
                        <select name="grootte" id="">
                            <option disabled selected>Maak een keuze</option>
                            <option value="s">Small (€5 - 10cm)</option>
                            <option value="m">Medium (€7 - 15cm)</option>
                            <option value="l">Large (€10 - 20cm)</option>
                            <option value="xl">Xtra Large (€15 - 30cm)</option>
                        </select>
                    </label>
                    <span class="error">
                        Grootte is verplicht
                    </span>
                </div>
                <div>
                    <label>
                        <span class="label">Bodem:</span> 
                        <select name="bodem" id="">
                            <option disabled selected>Maak een keuze</option>
                            <option value="dik">Dik</option>
                            <option value="dun">Dun</option>
                        </select>
                    </label>
                </div>
                <div>
                    <label>
                        <span class="label">Korst:</span> 
                        <select name="korst" id="">
                            <option disabled selected>Maak een keuze</option>
                            <option value="normaal">Normaal</option>
                            <option value="cheesy">Cheesy (€2)</option>
                        </select>
                    </label>
                </div>
                <div>
                    <span class="label">Saus:</span>
                    <label>
                        <input type="radio" name="saus" value="rood"> Rode saus
                    </label>
                    <label>
                        <input type="radio" name="saus" value="wit"> Witte saus
                    </label>
                </div>
            </fieldset>
            <fieldset>
                <legend>Toppings</legend>
                <div>
                    <p class="label">Kaas</p>
                    <ul>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="kaas"> Geraspte Kaas (€1)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="mozzarella"> Mozzarella (€1)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="feta"> Feta (€1)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="gorgonzola"> Gorgonzola (€2)
                            </label>
                        </li>
                    </ul>
                </div>
                <div>
                    <p class="label">Vlees & Vis</p>
                    <ul>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="kip"> Kip (€2)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="salami"> Salami (€2)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="kebap"> Kebap (€2)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="tonijn"> Tonijn (€2)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="zalm"> Zalm (€2)
                            </label>
                        </li>
                    </ul>
                </div>
                <div>
                    <p class="label">Extra</p>
                    <ul>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="olijven"> Olijven (€1)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="pepers"> Pepers (€1)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="champignons"> Champignons (€1)
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="checkbox" name="toppings" value="ajuin"> Ajuin (€1)
                            </label>
                        </li>
                    </ul>
                </div>
            </fieldset>
            <fieldset>
                <legend>Pikant</legend>
                <div>                        
                    <div class="pikant">
                        <input type="range" name="pikant" min="0" max="10">
                        <div>
                            <span>Niet pikant</span>
                            <span>Heel pikant</span>
                        </div>
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend>Jouw gegevens</legend>
                <div>
                    <label for="naam">Naam</label>
                    <input type="text" name="naam" id="naam">
                </div>
                <div>
                    <label for="straat">Straat + Huisnummer</label>
                    <input type="text" name="straat" id="straat">
                </div>
                <div>
                    <label for="gemeente">Postcode + Gemeente</label>
                    <input type="text" name="gemeente" id="gemeente">
                </div>
                <div>
                    <label for="email">E-mailadres</label>
                    <input type="text" name="email" id="email">
                </div>
                <div>
                    <label for="tel">Telefoonnummer</label>
                    <input type="text" name="tel" id="tel">
                </div>
            </fieldset>

            <input type="submit" value="Bestelling plaatsen" class="submit">
        </form>

        <footer class="footer">
            Met het plaatsen van een bestelling ga je akkoord met de algemene voorwaarden.
        </footer>
    </div>
    
</body>
</html>